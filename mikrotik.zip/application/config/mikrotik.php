<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
$config['hostname_mikrotik'] = '192.168.88.1';
$config['username_mikrotik'] = 'admin';
$config['password_mikrotik'] = 'masuk123';